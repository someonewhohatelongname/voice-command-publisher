#include <rclcpp/rclcpp.hpp>
//#include <mavros_msgs/msg/command_long.hpp>
#include <mavros_msgs/srv/command_long.hpp>
//#include <mavros_msgs/msg/set_mode.hpp>
#include <mavros_msgs/srv/set_mode.hpp>
#include <mavros_msgs/srv/command_bool.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <thread>
#include <stdexcept>
#include <iostream>
#include <chrono>

using namespace std::chrono_literals;

struct UdpVehicleCommand {
    uint16_t command;
    float param1;
    float param2;
    uint8_t target_system;
    uint8_t target_component;
    uint8_t source_system;
    uint8_t source_component;
    bool from_external;
};

class UdpRosBridge : public rclcpp::Node {
public:
    UdpRosBridge(int port) : Node("udp_ros_bridge"), udp_port_(port) {
        setupPublishersAndClients();
        setupUdpSocket();
        RCLCPP_INFO(this->get_logger(), "UDP ROS Bridge listening on UDP port %d", udp_port_);
        startReceiveThread();
    }

    ~UdpRosBridge() {
        running_ = false;
        if (receive_thread_.joinable()) {
            receive_thread_.join();
        }
        close(sock_fd_);
    }

private:
    void setupPublishersAndClients() {
        // Publishers
        setpoint_position_pub_ = create_publisher<geometry_msgs::msg::PoseStamped>("/mavros/setpoint_position/local", 10);
        
        // Service clients
        command_client_ = create_client<mavros_msgs::srv::CommandLong>("/mavros/cmd/command");
        arming_client_ = create_client<mavros_msgs::srv::CommandBool>("/mavros/cmd/arming");
        set_mode_client_ = create_client<mavros_msgs::srv::SetMode>("/mavros/set_mode");
    }

    void setupUdpSocket() {
        sock_fd_ = socket(AF_INET, SOCK_DGRAM, 0);
        if (sock_fd_ < 0) {
            throw std::runtime_error("Failed to create UDP socket");
        }

        struct sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(udp_port_);

        if (bind(sock_fd_, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            throw std::runtime_error("Failed to bind UDP socket");
        }
    }

    void startReceiveThread() {
        receive_thread_ = std::thread([this]() {
            while (running_) {
                UdpVehicleCommand udp_cmd;
                struct sockaddr_in client_addr;
                socklen_t client_len = sizeof(client_addr);

                ssize_t received = recvfrom(sock_fd_, &udp_cmd, sizeof(udp_cmd), 0,
                                            (struct sockaddr*)&client_addr, &client_len);

                if (received > 0) {
                    // Print information about the sender
                    RCLCPP_INFO(this->get_logger(), "Received %zd bytes from %s:%d", 
                                received, inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
                    processUdpCommand(udp_cmd);
                }
            }
        });
    }

    void processUdpCommand(const UdpVehicleCommand& udp_cmd) {
        // Print the details of the UDP command
        RCLCPP_INFO(this->get_logger(), 
            "UDP Command - command: %u, param1: %.2f, param2: %.2f, target_system: %u, target_component: %u, source_system: %u, source_component: %u, from_external: %d",
            udp_cmd.command,
            udp_cmd.param1,
            udp_cmd.param2,
            udp_cmd.target_system,
            udp_cmd.target_component,
            udp_cmd.source_system,
            udp_cmd.source_component,
            udp_cmd.from_external);

        // Send command via MAVROS
        auto request = std::make_shared<mavros_msgs::srv::CommandLong::Request>();
        request->command = udp_cmd.command;
        request->param1 = udp_cmd.param1;
        request->param2 = udp_cmd.param2;
        request->param3 = 0.0;
        request->param4 = 0.0;
        request->param5 = 0.0;
        request->param6 = 0.0;
        request->param7 = 0.0;
        
        // Handle special cases
        if (udp_cmd.command == 176 && udp_cmd.param2 == 6.0f) { // Offboard mode
            std::this_thread::sleep_for(2s);
            arm(true);
            auto start_time = this->now();
            
            // Set to OFFBOARD mode
            setMode("OFFBOARD");
            
            while ((this->now() - start_time).seconds() < 10) {
                publishSetpoint();
                std::this_thread::sleep_for(20ms);
            }
            
            landDrone();
            RCLCPP_INFO(this->get_logger(), "Land command sent. Waiting for the drone to land...");
            std::this_thread::sleep_for(20s);
            arm(false);
            RCLCPP_INFO(this->get_logger(), "Disarm command sent.");
            std::this_thread::sleep_for(4s);
            setMode("MANUAL");
            RCLCPP_INFO(this->get_logger(), "Manual mode command sent.");
        } else {
            // Send the command directly
            auto result_future = command_client_->async_send_request(request);
            std::this_thread::sleep_for(100ms);
        }
    }

    void arm(bool arm_state) {
        auto request = std::make_shared<mavros_msgs::srv::CommandBool::Request>();
        request->value = arm_state;
        
        auto result_future = arming_client_->async_send_request(request);
        
        if (rclcpp::spin_until_future_complete(this->get_node_base_interface(), result_future) ==
            rclcpp::FutureReturnCode::SUCCESS) {
            auto result = result_future.get();
            RCLCPP_INFO(this->get_logger(), "Arming result: %s", result->success ? "success" : "failure");
        } else {
            RCLCPP_ERROR(this->get_logger(), "Failed to call arming service");
        }
    }

    void setMode(const std::string& mode) {
        auto request = std::make_shared<mavros_msgs::srv::SetMode::Request>();
        request->custom_mode = mode;
        
        auto result_future = set_mode_client_->async_send_request(request);
        
        if (rclcpp::spin_until_future_complete(this->get_node_base_interface(), result_future) ==
            rclcpp::FutureReturnCode::SUCCESS) {
            auto result = result_future.get();
            RCLCPP_INFO(this->get_logger(), "Set mode result: %s", result->mode_sent ? "success" : "failure");
        } else {
            RCLCPP_ERROR(this->get_logger(), "Failed to call set_mode service");
        }
    }

    void sendCommand(uint16_t command, float param1 = 0.0, float param2 = 0.0, 
                    float param3 = 0.0, float param4 = 0.0,
                    float param5 = 0.0, float param6 = 0.0, float param7 = 0.0) {
        auto request = std::make_shared<mavros_msgs::srv::CommandLong::Request>();
        request->command = command;
        request->param1 = param1;
        request->param2 = param2;
        request->param3 = param3;
        request->param4 = param4;
        request->param5 = param5;
        request->param6 = param6;
        request->param7 = param7;
        
        auto result_future = command_client_->async_send_request(request);
        
        if (rclcpp::spin_until_future_complete(this->get_node_base_interface(), result_future) ==
            rclcpp::FutureReturnCode::SUCCESS) {
            auto result = result_future.get();
            RCLCPP_INFO(this->get_logger(), "Command result: %s", result->success ? "success" : "failure");
        } else {
            RCLCPP_ERROR(this->get_logger(), "Failed to call command service");
        }
    }

    void landDrone() {
        // MAV_CMD_NAV_LAND = 21
        sendCommand(21);
    }
    
    void publishSetpoint() {
        auto pose_msg = geometry_msgs::msg::PoseStamped();
        pose_msg.header.stamp = this->get_clock()->now();
        pose_msg.header.frame_id = "map";
        pose_msg.pose.position.x = 0.0;
        pose_msg.pose.position.y = 0.0;
        pose_msg.pose.position.z = 1.0;  // 1 meter altitude
        
        // Set orientation (quaternion for yaw=0)
        pose_msg.pose.orientation.x = 0.0;
        pose_msg.pose.orientation.y = 0.0;
        pose_msg.pose.orientation.z = 0.0;
        pose_msg.pose.orientation.w = 1.0;
        
        setpoint_position_pub_->publish(pose_msg);
    }

    rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr setpoint_position_pub_;
    rclcpp::Client<mavros_msgs::srv::CommandLong>::SharedPtr command_client_;
    rclcpp::Client<mavros_msgs::srv::CommandBool>::SharedPtr arming_client_;
    rclcpp::Client<mavros_msgs::srv::SetMode>::SharedPtr set_mode_client_;
    
    int udp_port_;
    int sock_fd_;
    bool running_ = true;
    std::thread receive_thread_;
};

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <udp_port>" << std::endl;
        return 1;
    }

    rclcpp::init(argc, argv);
    auto node = std::make_shared<UdpRosBridge>(std::stoi(argv[1]));
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}