#include <rclcpp/rclcpp.hpp>
#include <px4_msgs/msg/vehicle_command.hpp>
#include <px4_msgs/msg/offboard_control_mode.hpp>
#include <px4_msgs/msg/trajectory_setpoint.hpp>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <thread>
#include <chrono>

using namespace std::chrono_literals;

struct UdpVehicleCommand {
    uint16_t command;
    float param1;
    float param2;
    uint8_t target_system;
    uint8_t target_component;
    uint8_t source_system;
    uint8_t source_component;
    bool from_external;
};

class UdpRosBridge : public rclcpp::Node {
public:
    UdpRosBridge(int port) : Node("udp_ros_bridge"), udp_port_(port) {
        setupPublishers();
        setupUdpSocket();
        RCLCPP_INFO(this->get_logger(), "UDP ROS Bridge listening on port %d", udp_port_);
        startReceiveThread();
    }

    ~UdpRosBridge() {
        running_ = false;
        if (receive_thread_.joinable()) {
            receive_thread_.join();
        }
        close(sock_fd_);
    }

private:
    void setupPublishers() {
        vehicle_command_pub_ = create_publisher<px4_msgs::msg::VehicleCommand>("/fmu/in/vehicle_command", 10);
        trajectory_setpoint_pub_ = create_publisher<px4_msgs::msg::TrajectorySetpoint>("/fmu/in/trajectory_setpoint", 10);
        offboard_control_mode_pub_ = create_publisher<px4_msgs::msg::OffboardControlMode>("/fmu/in/offboard_control_mode", 10);
    }

    void setupUdpSocket() {
        sock_fd_ = socket(AF_INET, SOCK_DGRAM, 0);
        if (sock_fd_ < 0) {
            throw std::runtime_error("Failed to create UDP socket");
        }

        struct sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_addr.s_addr = INADDR_ANY;
        addr.sin_port = htons(udp_port_);

        if (bind(sock_fd_, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
            throw std::runtime_error("Failed to bind UDP socket");
        }
    }

    void startReceiveThread() {
        receive_thread_ = std::thread([this]() {
            while (running_) {
                UdpVehicleCommand udp_cmd;
                struct sockaddr_in client_addr;
                socklen_t client_len = sizeof(client_addr);

                ssize_t received = recvfrom(sock_fd_, &udp_cmd, sizeof(udp_cmd), 0,
                                          (struct sockaddr*)&client_addr, &client_len);

                if (received > 0) {
                    processUdpCommand(udp_cmd);
                }
            }
        });
    }

    void processUdpCommand(const UdpVehicleCommand& udp_cmd) {
        auto msg = px4_msgs::msg::VehicleCommand();
        msg.timestamp = this->now().nanoseconds() / 1000;
        msg.param1 = udp_cmd.param1;
        msg.param2 = udp_cmd.param2;
        msg.command = udp_cmd.command;
        msg.target_system = udp_cmd.target_system;
        msg.target_component = udp_cmd.target_component;
        msg.source_system = udp_cmd.source_system;
        msg.source_component = udp_cmd.source_component;
        msg.from_external = udp_cmd.from_external;

        vehicle_command_pub_->publish(msg);

        // If this is an offboard mode command, start publishing offboard control mode and trajectory
        if (udp_cmd.command == 176 && udp_cmd.param2 == 6.0f) {  // Set mode to OFFBOARD
            publishOffboardControl();
        }
    }

    void publishOffboardControl() {
        auto timer = this->create_wall_timer(100ms, [this]() {
            publishOffboardControlMode();
            publishTrajectorySetpoint();
        });
        
        // Store the timer to keep it alive
        offboard_timer_ = timer;
    }

    void publishOffboardControlMode() {
        auto msg = px4_msgs::msg::OffboardControlMode();
        msg.timestamp = this->now().nanoseconds() / 1000;
        msg.position = true;
        msg.velocity = false;
        msg.acceleration = false;
        msg.attitude = false;
        msg.body_rate = false;
        offboard_control_mode_pub_->publish(msg);
    }

    void publishTrajectorySetpoint() {
        auto msg = px4_msgs::msg::TrajectorySetpoint();
        msg.timestamp = this->now().nanoseconds() / 1000;
        msg.position = {0.0, 0.0, -5.0};  // Hover at 5 meters
        msg.yaw = -3.14;  // Facing north
        trajectory_setpoint_pub_->publish(msg);
    }

    rclcpp::Publisher<px4_msgs::msg::VehicleCommand>::SharedPtr vehicle_command_pub_;
    rclcpp::Publisher<px4_msgs::msg::TrajectorySetpoint>::SharedPtr trajectory_setpoint_pub_;
    rclcpp::Publisher<px4_msgs::msg::OffboardControlMode>::SharedPtr offboard_control_mode_pub_;
    rclcpp::TimerBase::SharedPtr offboard_timer_;
    
    int udp_port_;
    int sock_fd_;
    bool running_ = true;
    std::thread receive_thread_;
};

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <udp_port>" << std::endl;
        return 1;
    }

    rclcpp::init(argc, argv);
    auto node = std::make_shared<UdpRosBridge>(std::stoi(argv[1]));
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}